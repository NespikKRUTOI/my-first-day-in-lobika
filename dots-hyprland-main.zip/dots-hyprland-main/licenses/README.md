# Licenses

This repository contains code from other repositories. Files containing such code should include a license notice, and a copy should be stored in this folder.
